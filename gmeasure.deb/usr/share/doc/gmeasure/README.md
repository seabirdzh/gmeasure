About
=====

app logo is picked from Kruler project, and thanks to those guys.
